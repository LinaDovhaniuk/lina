/****************************************************************************
** Meta object code from reading C++ file 'addclient.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.6.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../lastV/addclient.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'addclient.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.6.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_AddClient_t {
    QByteArrayData data[14];
    char stringdata0[194];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_AddClient_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_AddClient_t qt_meta_stringdata_AddClient = {
    {
QT_MOC_LITERAL(0, 0, 9), // "AddClient"
QT_MOC_LITERAL(1, 10, 13), // "on_ok_clicked"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 20), // "on_clientBox_clicked"
QT_MOC_LITERAL(4, 46, 19), // "on_coachBox_clicked"
QT_MOC_LITERAL(5, 66, 19), // "on_adminBox_clicked"
QT_MOC_LITERAL(6, 86, 15), // "on_back_clicked"
QT_MOC_LITERAL(7, 102, 11), // "check_phone"
QT_MOC_LITERAL(8, 114, 10), // "check_name"
QT_MOC_LITERAL(9, 125, 16), // "check_finishTime"
QT_MOC_LITERAL(10, 142, 10), // "check_date"
QT_MOC_LITERAL(11, 153, 13), // "check_surname"
QT_MOC_LITERAL(12, 167, 11), // "check_login"
QT_MOC_LITERAL(13, 179, 14) // "check_password"

    },
    "AddClient\0on_ok_clicked\0\0on_clientBox_clicked\0"
    "on_coachBox_clicked\0on_adminBox_clicked\0"
    "on_back_clicked\0check_phone\0check_name\0"
    "check_finishTime\0check_date\0check_surname\0"
    "check_login\0check_password"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_AddClient[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   74,    2, 0x08 /* Private */,
       3,    0,   75,    2, 0x08 /* Private */,
       4,    0,   76,    2, 0x08 /* Private */,
       5,    0,   77,    2, 0x08 /* Private */,
       6,    0,   78,    2, 0x08 /* Private */,
       7,    0,   79,    2, 0x08 /* Private */,
       8,    0,   80,    2, 0x08 /* Private */,
       9,    0,   81,    2, 0x08 /* Private */,
      10,    0,   82,    2, 0x08 /* Private */,
      11,    0,   83,    2, 0x08 /* Private */,
      12,    0,   84,    2, 0x08 /* Private */,
      13,    0,   85,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Bool,

       0        // eod
};

void AddClient::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        AddClient *_t = static_cast<AddClient *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_ok_clicked(); break;
        case 1: _t->on_clientBox_clicked(); break;
        case 2: _t->on_coachBox_clicked(); break;
        case 3: _t->on_adminBox_clicked(); break;
        case 4: _t->on_back_clicked(); break;
        case 5: { bool _r = _t->check_phone();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 6: { bool _r = _t->check_name();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 7: { bool _r = _t->check_finishTime();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 8: { bool _r = _t->check_date();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 9: { bool _r = _t->check_surname();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 10: { bool _r = _t->check_login();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 11: { bool _r = _t->check_password();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        default: ;
        }
    }
}

const QMetaObject AddClient::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_AddClient.data,
      qt_meta_data_AddClient,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *AddClient::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *AddClient::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_AddClient.stringdata0))
        return static_cast<void*>(const_cast< AddClient*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int AddClient::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 12;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
