#ifndef FINDFORM_H
#define FINDFORM_H

#include <QMainWindow>
#include <QSqlTableModel>
/*
namespace Ui {
class findForm;
}

class findForm : public QMainWindow
{
    Q_OBJECT

public:
    explicit findForm(QWidget *parent = 0);
    ~findForm();

private slots:
    void on_ok_clicked();

private:
    Ui::findForm *ui;
};*/
#endif // FINDFORM_H
