#ifndef CONNECTEDCLIENT_H
#define CONNECTEDCLIENT_H
#include "user.h"

extern user* us;

#endif // CONNECTEDCLIENT_H
